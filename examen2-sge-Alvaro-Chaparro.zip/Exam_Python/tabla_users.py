import json

import pandas as pd
personas = {}
file = open("secure-users.json", "r")
nombre = json.load(file)
#Arrays donde van a ir guardados los datos del JSON
nombres=[]
for item in nombre:
    id = item['userId']
    nombres.append(id)
#Mismo array que el anterior donde se guardan los datos del json
contra =[]
for item in nombre:
    password = item['password']
    contra.append(password)
#Creamos las dos columnas de nombres userId y password junto con el Id
df = pd.DataFrame({'userId': nombres, 'password': contra})
df.index.name = 'ID'
df.to_excel("usuario.xlsx")#Creamos el excel