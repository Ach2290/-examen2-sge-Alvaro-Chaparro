import hashlib
import json

# Función para leer el archivo JSON e introducir los datos leidos en un array que devuelve
usuario = {}
file = open("users.json", "r")
usuario = json.load(file)

print(usuario)
#Hasheamos lo que está desntro del password
for item in usuario:
    password = item['password']
    hash_password = hashlib.sha1(password.encode()).hexdigest()
    item['password'] = hash_password
#Creamos nuevo json
newfile = open("secure-users.json", "w")
json.dump(usuario,newfile, indent=1)

